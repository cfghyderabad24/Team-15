import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import Profile from '../components/Profile';
import { Routes, Route } from 'react-router-dom';
import CreateEvent from '../pages/CreateEvent';
import ManageEvents from '../pages/ManageEvents';
import ManageUsers from '../pages/ManageUsers';
import MyEvents from '../pages/MyEvents';
import AboutUs from '../pages/AboutUs';
import Welcome from '../pages/Welcome';

const Home = ({ isAuthenticated }) => {
  const [expanded, setExpanded] = useState(true);

  const handleToggle = () => {
    setExpanded(!expanded);
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar isAuthenticated={isAuthenticated} onToggle={handleToggle} expanded={expanded} />
      <div className="flex-1 overflow-y-auto ml-0 p-4">
        <Routes>
          <Route path='/' element={<Welcome/>} />
          <Route path='/profile' element={<Profile />} />
          <Route path='/createvnt' element={<CreateEvent />} />
          <Route path='/myevnts' element={<MyEvents />} />
          <Route path='/aboutus' element={<AboutUs />} />
          <Route path='/managevnt' element={<ManageEvents />} />
          <Route path='/manageusers' element={<ManageUsers />} />
        </Routes>
      </div>
    </div>
  );
}

export default Home;



// import React, { useState } from 'react';
// import Sidebar from '../components/Sidebar';
// import Profile from '../components/Profile';
// import { Routes, Route } from 'react-router-dom';
// import CreateEvent from '../pages/CreateEvent';
// import ManageEvents from '../pages/ManageEvents';
// import ManageUsers from '../pages/ManageUsers';
// import MyEvents from '../pages/MyEvents';
// import AboutUs from '../pages/AboutUs';
// import Welcome from '../pages/Welcome';

// const Home = ({ isAuthenticated }) => {
//   const [isSidebarExpanded, setIsSidebarExpanded] = useState(true);

//   const handleSidebarToggle = () => {
//     setIsSidebarExpanded(!isSidebarExpanded);
//   };

//   return (
//     <div className="flex h-screen overflow-hidden">
//       <Sidebar isAuthenticated={isAuthenticated} onToggle={handleSidebarToggle} expanded={isSidebarExpanded} />
//       <div className={`flex-1 overflow-y-auto p-4 m-0 transition-all duration-300 ${isSidebarExpanded ? 'ml-0' : 'ml-0'}`}>
//         <Routes>
//           <Route path='/' element={<Welcome />} />
//           <Route path='/profile' element={<Profile />} />
//           <Route path='/createvnt' element={<CreateEvent />} />
//           <Route path='/myevnts' element={<MyEvents />} />
//           <Route path='/aboutus' element={<AboutUs />} />
//           <Route path='/managevnt' element={<ManageEvents />} />
//           <Route path='/manageusers' element={<ManageUsers />} />
//         </Routes>
//       </div>
//     </div>
//   );
// }

// export default Home;
